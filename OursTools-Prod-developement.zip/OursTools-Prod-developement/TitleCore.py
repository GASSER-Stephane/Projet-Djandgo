from PIL import Image

import TitleEngine


def getEmptyBackground(x: int, y: int):
    return Image.new("RGBA", (x, y), (0, 0, 0, 0))

def crop(letterCoords, module_id, theme_id):
    letters = TitleEngine.getImage(module_id, theme_id, "letters")
    return letters.crop(letterCoords)

def paste(background, foreground, img_offset):
    background.paste(foreground, img_offset, foreground)
    return background


def createTitle(module_id: str, theme_id: str, word: str) -> Image:

    letter_size = TitleEngine.getLetterHeight(module_id, theme_id)
    blankBackground = getEmptyBackground(2000, letter_size)
    offset = 0

    for letter in word.upper():
        letter_pos_tuple = TitleEngine.getLetterPositionTuple(module_id, theme_id, letter)
        generated_text = paste(
            blankBackground,
            crop(letter_pos_tuple, module_id, theme_id),
            (offset, 0)
        )
        offset += TitleEngine.getLetterWitdh(module_id, theme_id, letter)

    return (generated_text.crop((0, 0, offset+1, letter_size)), offset+1)




def getFinalMenu(module_id: str, theme_id: str, word: str, menu_height: int) -> Image:

    dynamicalX = 255
    generated_text = createTitle(module_id, theme_id, word)[0]
    final_size = createTitle(module_id, theme_id, word)[1]

    def getBackgroundBackground(size, height):
        if size <= 97 and height == 6:
            return TitleEngine.getImage(module_id, theme_id, "small-6x9")

        elif size <= 128 and height == 6:
            return TitleEngine.getImage(module_id, theme_id, "medium-6x9")

        elif size <= 182 and height == 6:
            return TitleEngine.getImage(module_id, theme_id, "big-6x9")

        # 5X9

        elif size <= 97 and height == 5:
            return TitleEngine.getImage(module_id, theme_id, "small-5x9")

        elif size <= 128 and height == 5:
            return TitleEngine.getImage(module_id, theme_id, "medium-5x9")

        elif size <= 182 and height == 5:
            return TitleEngine.getImage(module_id, theme_id, "big-5x9")

        # 4X9

        elif size <= 97 and height == 4:
            return TitleEngine.getImage(module_id, theme_id, "small-4x9")

        elif size <= 128 and height == 4:
            return TitleEngine.getImage(module_id, theme_id, "medium-4x9")

        elif size <= 182 and height == 4:
            return TitleEngine.getImage(module_id, theme_id, "big-4x9")

        else:
            print("Mot trop long")

    def autocenterPosition() -> int:
        return int(dynamicalX / 2 - final_size / 2) + 1

    if menu_height == 6:
        whiteBackground = paste(getBackgroundBackground(final_size, menu_height), generated_text,
                                    (autocenterPosition(), 9))
    elif menu_height == 5:
        whiteBackground = paste(getBackgroundBackground(final_size, menu_height), generated_text,
                                    (autocenterPosition(), 27))

    return whiteBackground


# DOCUMENTATION DE LA MORT

#                              MODULE      THEME       WORD     HEIGHT
#                                |           |          |         |
#                                v           v          v         v

#getMenu("seasonskyV3", "noel", "ours engine", 5).save("generateV2.png")
#createTitle("evolucraftV3", "default", "warps")[0].save("title.png")
#createTitle("seasonskyV3", "noel", "warps")[0].save("title.png")