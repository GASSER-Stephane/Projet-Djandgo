from django.urls import path

from . import views

urlpatterns = [
    path('', views.accueil),
    path('accueil/', views.accueil),
    path('menu/', views.formulaire),
    path('titre/', views.wordgenerator),
    path('signup/', views.signup),
    path('login/', views.login),
    path('signup1/', views.signup1),
    path('logout', views.logout),
    path('login1/', views.login1),
]
