import json

from django.conf import settings
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.utils.safestring import mark_safe

from django.shortcuts import render
from . import models
from django.contrib.auth.models import User,auth
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from . import models
from .forms import GeneratorForm, WordForm, LivreForm, BiblioForm


import TitleCore
import TitleEngine


# Create your views here.
@login_required(login_url="/login")
def accueil(request):
    return render(request, "myfirstapp/accueil.html")

@login_required(login_url="/login")
def formulaire(request):

    js_object = mark_safe(json.dumps(TitleEngine.getModuleConfiguration()))

    if request.method == "POST":
        form = GeneratorForm(data=request.POST)
        if form.is_valid():
            datas = form.save()
            data_serveur = datas.serveur
            data_theme = datas.theme
            data_taille = datas.taille
            data_titre = datas.titre
            TitleCore.getFinalMenu(data_serveur, data_theme, data_titre, data_taille).save("myfirstapp/static/images/generated.png")

            return render(request, 'myfirstapp/menu.html', {'form': form, 'datas': datas, 'js_object': js_object})
        else:
            return render(request, 'myfirstapp/menu.html', {'form': form, 'js_object': js_object})
    else:
        form = GeneratorForm()
        return render(request, 'myfirstapp/menu.html', {'form': form, 'js_object': js_object})

@login_required(login_url="/login")
def wordgenerator(request):

    js_object = mark_safe(json.dumps(TitleEngine.getModuleConfiguration()))

    if request.method == "POST":
        form = WordForm(data=request.POST)
        if form.is_valid():
            datas = form.save()
            data_serveur = datas.serveur
            data_theme = datas.theme
            data_titre = datas.titre
            TitleCore.createTitle(data_serveur, data_theme, data_titre)[0].save("myfirstapp/static/images/wordgenerated.png")
            return render(request, 'myfirstapp/titre.html', {'form': form, 'datas': datas, 'js_object': js_object})
        else:
            return render(request, 'myfirstapp/titre.html', {'form': form, 'js_object': js_object})
    else:
        form = WordForm()
        return render(request, 'myfirstapp/titre.html', {'form': form, 'js_object': js_object})



def login(request):
    return render(request,'myfirstapp/login.html')

def signup(request):
    return render(request,'myfirstapp/registration.html')


def login1(request):
    if request.method == 'POST':
        username = request.POST['username']

        pass1 = request.POST['password']
        user = auth.authenticate(username=username, password=pass1)
        if user is not None:
            auth.login(request, user)
            return HttpResponseRedirect('/accueil')
        else:
            messages.info(request, 'Compte inexistant ! Veuillez vous relire')
            return render(request, 'myfirstapp/login.html')
    else:
        return render(request, 'myfirstapp/login.html')



def signup1(request):
 if request.method=="POST":
    username=request.POST['username']
    pass1=request.POST['password']
    pass2=request.POST['password1']
    if pass1==pass2:
            if User.objects.filter(username=username).exists():
                messages.info(request,'OOPS! Usename already taken')
                return render(request,'myfirstapp/registration.html')
            else:
                user=User.objects.create_user(username=username,password=pass1)
                user.save()
                messages.info(request,'Compte créé avec succès !')
                return render(request,'myfirstapp/login.html')
    else:
            messages.info(request,'Password do not match')
            return render(request,'myfirstapp/registration.html')



def logout(request):
    auth.logout(request)
    return HttpResponseRedirect('/accueil')